//Alpha X Software Company
//Mindula Dilthushan
// GMA v2.0.3
// 21-06-25
// Not Complete
$("#btnResetPassword").click(function () {
    let getEmail = $('#txtEmail').val();
    // email = string.replace(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    window.location = "http://localhost:63342/Gold-Medal-AutoMotive-v2.0.3/GMA-Frontend/src/common/login.html";
});