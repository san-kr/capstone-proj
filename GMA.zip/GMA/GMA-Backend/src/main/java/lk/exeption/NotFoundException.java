//Alpha X Software Company
//Mindula Dilthushan
//GMA v2.0.3
package lk.exeption;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {
        super(message);
    }
}
