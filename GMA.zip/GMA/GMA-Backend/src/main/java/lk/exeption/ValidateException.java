//Alpha X Software Company
//Mindula Dilthushan
//GMA v2.0.3
package lk.exeption;

public class ValidateException extends RuntimeException {

    public ValidateException(String message) {
        super(message);
    }
}