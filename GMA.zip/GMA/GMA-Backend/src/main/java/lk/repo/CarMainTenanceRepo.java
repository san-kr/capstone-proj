//Alpha X Software Company
//Mindula Dilthushan
//GMA v2.0.3
//21-06-19
package lk.repo;

import lk.entity.CarMainTenance;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarMainTenanceRepo extends JpaRepository<CarMainTenance,String>{
}
